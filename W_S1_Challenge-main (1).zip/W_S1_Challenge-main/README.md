# Sprint 1 Challenge

## Instructions

1. Open the `index.html` file in both VSCode and the Chrome browser.
2. In Chrome, open Dev Tools, Console tab.
3. Return to VSCode and start working on your Challenges.
4. Instructions for each Challenge can be found inside the script tag in `index.html`.
5. You can see test results in your Console.
6. Upload the completed `index.html` file to Codegrade.
